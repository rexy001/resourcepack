Author of this shader is Ancientkingg

This allowed to commercially use with reference to original author.
Original license: https://github.com/Ancientkingg/fancyPants/blob/master/README.md
